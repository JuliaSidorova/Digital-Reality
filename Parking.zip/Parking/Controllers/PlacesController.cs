﻿using System.Collections.Generic;
using System.Web.Http;
using DbConnect;
using DbConnect.db;
using DbConnect.Models;

namespace Parking.Controllers
{
    public class PlacesController : ApiController
    {
        private IDb db = SingeltonDb.GetDb();

        [HttpGet]
        public List<Place> GetPlaces()
        {
            return db.GetAllPlace();
        }

        [HttpPost]
        public void PostPlaces([FromBody]List<TLoadTMP> loadTmp)
        {
            db.SetParkinkPlace(loadTmp);
        }
    }
}
