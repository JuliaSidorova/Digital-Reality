﻿function Places() {
    //получены ли парковки
    var isGetPlace = false;

    //массив парковок
    var places = null;

    function GetColor(status) {
        return status == 1 ? '#00ff00' : '#ff0000'
    }

    function CountFree(places) {
        var count = 0;

        places.forEach(function (key) {
            if (key.status == 1) {
                count += 1;
            }
        })

        return count;
    }

    function CenterPlaces(places) {
        var latitude = 0;
        var longitude = 0;

        places.forEach(function (key) { latitude += key.px - 0, longitude += key.py - 0 });

        return {
            latitude: latitude / places.length,
            longitude: longitude / places.length
        }
    }

    function GetDiffPlacemant(places) {
        var free = { weight: 0, color: GetColor(1) };
        var busy = { weight: 0, color: GetColor(-1) };

            places.forEach(function (key) {
                if (key.status == 1) {
                    free.weight += 1;
                }
                else {
                    busy.weight += 1;
                }
            });

        return [free, busy];
    }

    return {
        places, places,
        isGetPlace, isGetPlace,
        GetColor: GetColor,
        CountFree: CountFree,
        CenterPlaces: CenterPlaces,
        GetDiffPlacemant: GetDiffPlacemant
    }
}

//получить парковки
function getPlaces(places) {
    places.isGetPlace = false;

    $.ajax({
        type: "GET",
        url: "api/Places",
        success: function (res) {
            places.places = res;
            places.isGetPlace = true;
        }
    });
}