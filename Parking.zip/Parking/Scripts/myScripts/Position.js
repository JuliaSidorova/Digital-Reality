﻿function Position(func, map) {

    var latitude;
    var longitude;
    var isLoad = false;

    function GiveGps(latitude, longitude) {
        func(latitude, longitude, map);
    }

    return {
        latitude: latitude,
        longitude: longitude,
        GiveGps: GiveGps,
        isLoad: isLoad
    };
}

//определение широты и долготы
function SetPosition(gps) {
    navigator.geolocation.getCurrentPosition(
        function (position) {
            //gps.latitude = position.coords.latitude;
            //gps.longitude = position.coords.longitude;
            gps.latitude = 56.851480;
            gps.longitude = 53.211944;
            gps.isLoad = true;
            gps.GiveGps(gps.latitude, gps.longitude);
        }
    );
};