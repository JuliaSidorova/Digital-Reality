﻿var requestAnimFrame = (function () {
    return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function (callback) {
            window.setTimeout(callback, 1000 / 60);
        };
})();

window.onload = function () {
    var CHANGE_VIEW = 17;
    var refresh = 10000;
    var places = new Places();
    var map = new YaMap();
    var position = new Position(map.init, map);
    var union = false;
    var isExistData = false;

    SetPosition(position);
    getPlaces(places);
    var LastTime = Date.now();
    GetWeathler(56.851480, 53.211944);

    function main() {
        var dt = Date.now() - LastTime;

        if (dt >= refresh) {
            getPlaces(places);
            LastTime = Date.now();
        }

        if (map.isLoad && places.isGetPlace) {
            isExistData = true;
            places.isGetPlace = false;

            updateMap();
        }


        requestAnimFrame(main);
    };

    main();

    document.addEventListener('click', function () {
        stakeout(map.GetSize(map));
    })

    document.addEventListener('wheel', function () {
        stakeout(map.GetSize(map));
    })

    function IsUnion(size) {
        return size < CHANGE_VIEW;
    }

    function stakeout(size) {
        lastUnion = union;
        union = IsUnion(map.GetSize(map));

        if (lastUnion != union && isExistData) {
            updateMap();
        }
    }

    function updateMap() {
        if (!union) {
            var poligons = [];

            places.places.forEach(function (key) {
                poligons.push(map.GetPoligon(key.px - 0, key.py - 0, places.GetColor(key.status), map));
            });

            map.DravingList(poligons, map);
            map.poligons = poligons;
        }
        else {
            var center = places.CenterPlaces(places.places);
            var weight = places.GetDiffPlacemant(places.places);
            var placemark = map.GetPlaceMark(center.latitude, center.longitude, weight);
            map.unions.push(placemark);
            map.DrawingObj(placemark, map)
        }
    }
}