﻿function GetWeathler(lat, lon) {
    $.ajax({
        type: "GET",
        url: "http://api.openweathermap.org/data/2.5/find?lat=" + lat + "&lon=" + lon,
        success: function (res) {
            console.log(res);
        }
    });
}