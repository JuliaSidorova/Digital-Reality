﻿function YaMap() {
    var isLoad = false;
    var myMap = null;
    var wigth = 0.000011;
    var height = 0.000032;
    var Rout = null;
    var poligons = [];
    var unions = [];

    //инициализация карты
    function init(latitude, longitude, map) {
        ymaps.ready(
            // Создание карты.    
            map.myMap = new ymaps.Map("map", {
                // Координаты центра карты.
                center: [latitude, longitude],
                // Уровень масштабирования. Допустимые значения:
                // от 0 (весь мир) до 19.
                zoom: 17
            })
        );

        //пробки
        var actualProvider = new ymaps.traffic.provider.Actual({}, {
            infoLayerShown: true
        });
        actualProvider.setMap(map.myMap);

        map.isLoad = true;
    }

    function GetSize(map) {
        return map.myMap.getZoom();
    }

    function GetPoligon(latitude, longitude, color, map) {
        var polygon = new ymaps.Polygon(
            [[[latitude + wigth, longitude + height],
            [latitude + wigth, longitude - height],
            [latitude - wigth, longitude - height],
            [latitude - wigth, longitude + height]]], {
                hintContent: "Место"
            }, {
                fillColor: color,
                outline: false,
                // Делаем полигон прозрачным для событий карты.
                interactivityModel: 'default#transparent',
                opacity: 0.5
            }
        );

        polygon.events.add('click', function () {map.Rout =  AddRoute(latitude, longitude, map) });

        return polygon;
    }

    function AddRoute(latitude, longitude, map) {
        var location = ymaps.geolocation.get();
        
        // Асинхронная обработка ответа.
        location.then(
            function (result) {
                var position = result.geoObjects.position;

                var multiRoute = new ymaps.multiRouter.MultiRoute({
                    referencePoints: [
                        position,
                        [latitude, longitude]
                    ]
                });

                map.myMap.geoObjects.add(multiRoute);

                return multiRoute;
            }
        );
    }

    function GetCluster(objs, map) {
        var clusterer = new ymaps.Clusterer({
        });

        objs.forEach(function (key) { clusterer.add(key) });

        map.myMap.geoObjects.add(clusterer);
    }

    function GetPlaceMark(latitude, longitude, plases) {
        var myPlacemark = new ymaps.Placemark([latitude, longitude], {
            //данные для диаграммы
            data: plases,
            iconContent: plases[0].weight + '/' + (plases[1].weight + plases[0].weight)
        }, {
                iconLayout: 'default#pieChart',
            });

        return myPlacemark;
    }

    function DravingList(poligons, map) {
        map.Clear(map);
        poligons.forEach(function (key) { map.myMap.geoObjects.add(key) });
        DrawRout(map);
    }

    function DrawingObj(obj, map) {
        map.Clear(map);
        map.myMap.geoObjects.add(obj);
        DrawRout(map);
    };

    function Clear(map) {
        //map.myMap.geoObjects.removeAll();
        map.poligons.forEach(function (key) { map.myMap.geoObjects.remove(key) });
        map.unions.forEach(function (key) { map.myMap.geoObjects.remove(key) });
        map.poligons = [];
        map.unions = [];
    }

    function DrawRout(map) {
        /*if (map.Rout != null) {
            map.myMap.geoObjects.add(map.Rout);
        }*/
    }

    return {
        myMap: myMap,
        DrawingObj: DrawingObj,
        init: init,
        isLoad: isLoad,
        Clear: Clear,
        GetPoligon: GetPoligon,
        GetCluster: GetCluster,
        DravingList: DravingList,
        GetPlaceMark: GetPlaceMark,
        GetSize: GetSize,
        poligons: poligons,
        unions: unions,
        Rout: Rout
    }
}