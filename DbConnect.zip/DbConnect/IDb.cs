﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbConnect
{
    public interface IDb: IGetParcking, ISetParkingTMP
    {
    }
}
