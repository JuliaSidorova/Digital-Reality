﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbConnect
{
    public class SingeltonDb
    {
        private static readonly DbParking db = new DbParking();

        public static IDb GetDb()
        {
            return db;
        }
    }
}
