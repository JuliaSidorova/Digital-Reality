﻿using DbConnect.db;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbConnect
{
    public interface ISetParkingTMP
    {
        /// <summary>
        /// записать данные по одному парковочному месту
        /// </summary>
        /// <param name="place">парковочное место</param>
        void SetParkinkPlace(TLoadTMP place);
        
        /// <summary>
        /// записать данные списка парковочных мест
        /// </summary>
        /// <param name="places">список парковочных мест</param>
        void SetParkinkPlace(List<TLoadTMP> places);
    }
}
