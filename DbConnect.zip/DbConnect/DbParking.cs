﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DbConnect.db;
using DbConnect.Models;

namespace DbConnect
{
    public class DbParking : IDb
    {
        /// <summary>
        /// получить список всех парковочных мест
        /// </summary>
        List<Place> IGetParcking.GetAllPlace()
        {
            using (var db = new Parking())
            {
                var placesDb = db.TPlace.ToList()
                    .ConvertAll(x => new Place() {
                                    id =x.id,
                                    type =(int)x.Type,
                                    px =x.px,py=x.py,
                                    opening =x.db,
                                    closing =x.de,
                                    status = db.TPlacesStatus.Where(y => y.IdPlace == x.id).ToList().LastOrDefault().status});
                return placesDb;
            }
        }

        void ISetParkingTMP.SetParkinkPlace(TLoadTMP place)
        {
            using (var db = new Parking())
            {
                db.TLoadTMP.Add(place);
                db.SaveChanges();
            }
        }

        void ISetParkingTMP.SetParkinkPlace(List<TLoadTMP> places)
        {
            using (var db = new Parking())
            {
                db.TLoadTMP.AddRange(places);
                db.SaveChanges();
            }
        }
    }
}
