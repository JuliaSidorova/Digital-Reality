﻿using DbConnect.db;
using DbConnect.Models;
using System.Collections.Generic;

namespace DbConnect
{
    public interface IGetParcking
    {
        /// <summary>
        /// получить список всех парковочных мест
        /// </summary>
        List<Place> GetAllPlace();
    }
}
