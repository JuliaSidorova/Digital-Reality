namespace DbConnect.db
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TPlace")]
    public partial class TPlace
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TPlace()
        {
            TLoadTMP = new HashSet<TLoadTMP>();
            TPlacesStatus = new HashSet<TPlacesStatus>();
        }

        public int id { get; set; }

        public TimeSpan? db { get; set; }

        public TimeSpan? de { get; set; }

        [Required]
        [StringLength(1000)]
        public string px { get; set; }

        [Required]
        [StringLength(1000)]
        public string py { get; set; }

        public int? Type { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<TLoadTMP> TLoadTMP { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<TPlacesStatus> TPlacesStatus { get; set; }
    }
}
