namespace DbConnect.db
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class TPlacesStatus
    {
        public Guid id { get; set; }

        public int IdPlace { get; set; }

        public int status { get; set; }

        public DateTime DB { get; set; }

        public DateTime? DE { get; set; }

        public virtual TPlace TPlace { get; set; }
    }
}
