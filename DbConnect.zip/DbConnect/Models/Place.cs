﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbConnect.Models
{
    public class Place
    {
        public int id { get; set; }

        public TimeSpan? opening { get; set; }

        public TimeSpan? closing { get; set; }

        public string px { get; set; }

        public string py { get; set; }

        public int type { get; set; }

        public int status { get; set; }
    }
}
