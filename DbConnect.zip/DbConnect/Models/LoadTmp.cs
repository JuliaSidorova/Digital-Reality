﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbConnect.Models
{
    public class LoadTmp
    {
        public int id { get; set; }

        public DateTime time { get; set; }

        public int status { get; set; }
    }
}
