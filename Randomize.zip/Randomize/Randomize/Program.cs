﻿using RandomMest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ToSQL;
using ToSQL.db;

namespace Randomize
{
    class Program
    {
        private const int SLEEP = 60000;
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Start");
                var sql = new WriteToSQL();
                var listId = sql.GetIdPlaces();
                var places = listId.ConvertAll(x => CreateDatePlace.GetRandomPlace(x));
                var placesDb = places.ConvertAll(x => new TLoadTMP() { IdPlace = x.idPlace, Dt = x.timeEvent, status = x.statusEvent });
                sql.WritePlaces(placesDb);
                Thread.Sleep(SLEEP);
                Console.Clear();
            }
        }
    }
}
