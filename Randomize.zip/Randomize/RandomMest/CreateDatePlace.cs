﻿using System;
using System.Threading;

namespace RandomMest
{
    public class CreateDatePlace
    {

        public static ParkingPlace GetRandomPlace(int idpl)
        {
            var random = new Random();
            Thread.Sleep(20); //для улучшения работы рандома
            var status = (int)Math.Pow(-1, random.Next());

            return new ParkingPlace()
            {
                idPlace = idpl,
                timeEvent = DateTime.Now,
                statusEvent = status
            };
        }
    }
}
