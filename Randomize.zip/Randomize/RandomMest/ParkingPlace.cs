﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomMest
{
    public class ParkingPlace
    {

        //id места на парковке
        public int idPlace { get; set; }

        //время события
        public DateTime timeEvent { get; set; }

        //статус события 1-занято 0 - свободно
        public int statusEvent { get; set; }
    }
}
