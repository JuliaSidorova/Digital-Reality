﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ToSQL.db;

namespace ToSQL
{
    public class WriteToSQL
    {
        //записать текущий статус
        public void WritePlaces(int id, DateTime time, int status)
        {
            using (var db = new Parking())
            {
                db.TLoadTMP.Add(new TLoadTMP() { IdPlace = id, Dt = time, status = status});
                db.SaveChanges();
            }
        }

        //записать текущий статус из списка
        public void WritePlaces(List<TLoadTMP> listTmp)
        {
            using (var db = new Parking())
            {
                db.TLoadTMP.AddRange(listTmp);
                db.SaveChanges();
            }
        }

        //получить список id площадок
        public List<int> GetIdPlaces()
        {
            using (var db = new Parking())
            {
                return db.TPlace.Select(x => x.id).ToList();
            }
        }
    }
}
