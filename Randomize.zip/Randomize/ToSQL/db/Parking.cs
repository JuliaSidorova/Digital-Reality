namespace ToSQL.db
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Parking : DbContext
    {
        public Parking()
            : base("name=Parking")
        {
        }

        public virtual DbSet<TPlace> TPlace { get; set; }
        public virtual DbSet<TLoadTMP> TLoadTMP { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TPlace>()
                .HasMany(e => e.TLoadTMP)
                .WithRequired(e => e.TPlace)
                .HasForeignKey(e => e.IdPlace)
                .WillCascadeOnDelete(false);
        }
    }
}
